#include "stdafx.h"
#include "QLife.h"

