#pragma once
#include "stdafx.h"
namespace ConsoleApplication4 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for QLife
	/// </summary>
	public ref class QLife : public System::Windows::Forms::Form
	{
	public:
		QLife(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~QLife()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:

















	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Label^  label1;

	private: System::Windows::Forms::TableLayoutPanel^  tableLayoutPanel1;
	private: System::Windows::Forms::RichTextBox^  richTextBox2;
	private: System::Windows::Forms::RichTextBox^  richTextBox1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::DataVisualization::Charting::Chart^  chart1;
	private: System::Windows::Forms::ToolStripMenuItem^  viewToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  dayToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  monthToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  weekToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  monthToolStripMenuItem1;
	private: System::Windows::Forms::ToolStripMenuItem^  yearToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  analysisToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  fixUpToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  settingsToolStripMenuItem;
	private: System::Windows::Forms::MenuStrip^  menuStrip2;



	protected:








	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataVisualization::Charting::ChartArea^  chartArea4 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Legend^  legend4 = (gcnew System::Windows::Forms::DataVisualization::Charting::Legend());
			System::Windows::Forms::DataVisualization::Charting::Series^  series4 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			System::Windows::Forms::DataVisualization::Charting::DataPoint^  dataPoint10 = (gcnew System::Windows::Forms::DataVisualization::Charting::DataPoint(0,
				2));
			System::Windows::Forms::DataVisualization::Charting::DataPoint^  dataPoint11 = (gcnew System::Windows::Forms::DataVisualization::Charting::DataPoint(0,
				3));
			System::Windows::Forms::DataVisualization::Charting::DataPoint^  dataPoint12 = (gcnew System::Windows::Forms::DataVisualization::Charting::DataPoint(0,
				5));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->tableLayoutPanel1 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox2 = (gcnew System::Windows::Forms::RichTextBox());
			this->chart1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->viewToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->dayToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->monthToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->weekToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->monthToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->yearToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->analysisToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->fixUpToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->settingsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->menuStrip2 = (gcnew System::Windows::Forms::MenuStrip());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart1))->BeginInit();
			this->menuStrip2->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14, System::Drawing::FontStyle::Bold));
			this->label1->Location = System::Drawing::Point(54, 24);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(157, 24);
			this->label1->TabIndex = 2;
			this->label1->Text = L"November 2016";
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->button2->Location = System::Drawing::Point(12, 16);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(36, 41);
			this->button2->TabIndex = 4;
			this->button2->Text = L"<";
			this->button2->UseVisualStyleBackColor = false;
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->button3->Location = System::Drawing::Point(217, 12);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(36, 41);
			this->button3->TabIndex = 5;
			this->button3->Text = L">";
			this->button3->UseVisualStyleBackColor = false;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12));
			this->label2->Location = System::Drawing::Point(12, 105);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(65, 20);
			this->label2->TabIndex = 6;
			this->label2->Text = L"Monday";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12));
			this->label3->Location = System::Drawing::Point(96, 105);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(69, 20);
			this->label3->TabIndex = 7;
			this->label3->Text = L"Tuesday";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12));
			this->label4->Location = System::Drawing::Point(382, 105);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(52, 20);
			this->label4->TabIndex = 8;
			this->label4->Text = L"Friday";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12));
			this->label5->Location = System::Drawing::Point(281, 105);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(74, 20);
			this->label5->TabIndex = 9;
			this->label5->Text = L"Thursday";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12));
			this->label6->Location = System::Drawing::Point(171, 105);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(93, 20);
			this->label6->TabIndex = 10;
			this->label6->Text = L"Wednesday";
			this->label6->Click += gcnew System::EventHandler(this, &QLife::label6_Click);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12));
			this->label7->Location = System::Drawing::Point(546, 105);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(63, 20);
			this->label7->TabIndex = 11;
			this->label7->Text = L"Sunday";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12));
			this->label8->Location = System::Drawing::Point(460, 105);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(73, 20);
			this->label8->TabIndex = 12;
			this->label8->Text = L"Saturday";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12));
			this->label9->Location = System::Drawing::Point(639, 285);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(98, 20);
			this->label9->TabIndex = 13;
			this->label9->Text = L"Suggestions";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12));
			this->label10->Location = System::Drawing::Point(748, 285);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(96, 20);
			this->label10->TabIndex = 14;
			this->label10->Text = L"Notifications";
			this->label10->Click += gcnew System::EventHandler(this, &QLife::label10_Click);
			// 
			// tableLayoutPanel1
			// 
			this->tableLayoutPanel1->CellBorderStyle = System::Windows::Forms::TableLayoutPanelCellBorderStyle::OutsetDouble;
			this->tableLayoutPanel1->ColumnCount = 7;
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				47.79874F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				52.20126F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				98)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				91)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				82)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				83)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Absolute,
				77)));
			this->tableLayoutPanel1->Location = System::Drawing::Point(12, 140);
			this->tableLayoutPanel1->Name = L"tableLayoutPanel1";
			this->tableLayoutPanel1->RowCount = 4;
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 50)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 50)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 105)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Absolute, 87)));
			this->tableLayoutPanel1->Size = System::Drawing::Size(609, 419);
			this->tableLayoutPanel1->TabIndex = 17;
			this->tableLayoutPanel1->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &QLife::tableLayoutPanel1_Paint);
			// 
			// richTextBox1
			// 
			this->richTextBox1->Location = System::Drawing::Point(637, 308);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(100, 240);
			this->richTextBox1->TabIndex = 18;
			this->richTextBox1->Text = L"Will be Label";
			// 
			// richTextBox2
			// 
			this->richTextBox2->Location = System::Drawing::Point(752, 308);
			this->richTextBox2->Name = L"richTextBox2";
			this->richTextBox2->Size = System::Drawing::Size(100, 240);
			this->richTextBox2->TabIndex = 19;
			this->richTextBox2->Text = L"Will be Label";
			this->richTextBox2->TextChanged += gcnew System::EventHandler(this, &QLife::richTextBox2_TextChanged);
			// 
			// chart1
			// 
			chartArea4->Name = L"ChartArea1";
			this->chart1->ChartAreas->Add(chartArea4);
			legend4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 5));
			legend4->IsTextAutoFit = false;
			legend4->LegendStyle = System::Windows::Forms::DataVisualization::Charting::LegendStyle::Row;
			legend4->Name = L"Legend1";
			legend4->Position->Auto = false;
			legend4->Position->Height = 8;
			legend4->Position->Width = 90.10368F;
			legend4->Position->X = 1;
			legend4->Position->Y = 92;
			legend4->TableStyle = System::Windows::Forms::DataVisualization::Charting::LegendTableStyle::Wide;
			this->chart1->Legends->Add(legend4);
			this->chart1->Location = System::Drawing::Point(626, 0);
			this->chart1->Name = L"chart1";
			series4->ChartArea = L"ChartArea1";
			series4->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Pie;
			series4->Legend = L"Legend1";
			series4->Name = L"Series1";
			dataPoint10->Label = L"Study";
			dataPoint11->Label = L"Social";
			dataPoint12->Label = L"Exercise";
			series4->Points->Add(dataPoint10);
			series4->Points->Add(dataPoint11);
			series4->Points->Add(dataPoint12);
			this->chart1->Series->Add(series4);
			this->chart1->Size = System::Drawing::Size(243, 282);
			this->chart1->TabIndex = 20;
			this->chart1->Text = L"chart1";
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->button1->Location = System::Drawing::Point(561, 52);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(48, 41);
			this->button1->TabIndex = 21;
			this->button1->Text = L"+";
			this->button1->UseVisualStyleBackColor = false;
			// 
			// viewToolStripMenuItem
			// 
			this->viewToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->viewToolStripMenuItem->Margin = System::Windows::Forms::Padding(0, 20, 0, 20);
			this->viewToolStripMenuItem->Name = L"viewToolStripMenuItem";
			this->viewToolStripMenuItem->Size = System::Drawing::Size(79, 28);
			this->viewToolStripMenuItem->Text = L"View";
			// 
			// dayToolStripMenuItem
			// 
			this->dayToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->dayToolStripMenuItem->Margin = System::Windows::Forms::Padding(0, 20, 0, 20);
			this->dayToolStripMenuItem->Name = L"dayToolStripMenuItem";
			this->dayToolStripMenuItem->Size = System::Drawing::Size(79, 28);
			this->dayToolStripMenuItem->Text = L"Day";
			// 
			// monthToolStripMenuItem
			// 
			this->monthToolStripMenuItem->Name = L"monthToolStripMenuItem";
			this->monthToolStripMenuItem->Size = System::Drawing::Size(79, 4);
			// 
			// weekToolStripMenuItem
			// 
			this->weekToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->weekToolStripMenuItem->Margin = System::Windows::Forms::Padding(0, 20, 0, 20);
			this->weekToolStripMenuItem->Name = L"weekToolStripMenuItem";
			this->weekToolStripMenuItem->Size = System::Drawing::Size(79, 28);
			this->weekToolStripMenuItem->Text = L"Week";
			// 
			// monthToolStripMenuItem1
			// 
			this->monthToolStripMenuItem1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->monthToolStripMenuItem1->Margin = System::Windows::Forms::Padding(0, 20, 0, 20);
			this->monthToolStripMenuItem1->Name = L"monthToolStripMenuItem1";
			this->monthToolStripMenuItem1->Size = System::Drawing::Size(79, 28);
			this->monthToolStripMenuItem1->Text = L"Month";
			// 
			// yearToolStripMenuItem
			// 
			this->yearToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->yearToolStripMenuItem->Margin = System::Windows::Forms::Padding(0, 20, 0, 20);
			this->yearToolStripMenuItem->Name = L"yearToolStripMenuItem";
			this->yearToolStripMenuItem->Size = System::Drawing::Size(79, 28);
			this->yearToolStripMenuItem->Text = L"Year";
			// 
			// analysisToolStripMenuItem
			// 
			this->analysisToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->analysisToolStripMenuItem->Margin = System::Windows::Forms::Padding(0, 20, 0, 20);
			this->analysisToolStripMenuItem->Name = L"analysisToolStripMenuItem";
			this->analysisToolStripMenuItem->Size = System::Drawing::Size(79, 28);
			this->analysisToolStripMenuItem->Text = L"Analysis";
			// 
			// fixUpToolStripMenuItem
			// 
			this->fixUpToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->fixUpToolStripMenuItem->Margin = System::Windows::Forms::Padding(0, 20, 0, 20);
			this->fixUpToolStripMenuItem->Name = L"fixUpToolStripMenuItem";
			this->fixUpToolStripMenuItem->Size = System::Drawing::Size(79, 28);
			this->fixUpToolStripMenuItem->Text = L"Fix Up";
			// 
			// settingsToolStripMenuItem
			// 
			this->settingsToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->settingsToolStripMenuItem->Margin = System::Windows::Forms::Padding(0, 20, 0, 20);
			this->settingsToolStripMenuItem->Name = L"settingsToolStripMenuItem";
			this->settingsToolStripMenuItem->Size = System::Drawing::Size(79, 28);
			this->settingsToolStripMenuItem->Text = L"Settings";
			// 
			// menuStrip2
			// 
			this->menuStrip2->Dock = System::Windows::Forms::DockStyle::Right;
			this->menuStrip2->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(9) {
				this->viewToolStripMenuItem,
					this->dayToolStripMenuItem, this->monthToolStripMenuItem, this->weekToolStripMenuItem, this->monthToolStripMenuItem1, this->yearToolStripMenuItem,
					this->analysisToolStripMenuItem, this->fixUpToolStripMenuItem, this->settingsToolStripMenuItem
			});
			this->menuStrip2->Location = System::Drawing::Point(872, 0);
			this->menuStrip2->Margin = System::Windows::Forms::Padding(0, 10, 0, 10);
			this->menuStrip2->Name = L"menuStrip2";
			this->menuStrip2->Padding = System::Windows::Forms::Padding(11, 4, 0, 4);
			this->menuStrip2->Size = System::Drawing::Size(102, 569);
			this->menuStrip2->TabIndex = 1;
			this->menuStrip2->Text = L"menuStrip2";
			this->menuStrip2->ItemClicked += gcnew System::Windows::Forms::ToolStripItemClickedEventHandler(this, &QLife::menuStrip2_ItemClicked);
			// 
			// QLife
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(11, 24);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightSkyBlue;
			this->ClientSize = System::Drawing::Size(974, 569);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->chart1);
			this->Controls->Add(this->richTextBox2);
			this->Controls->Add(this->richTextBox1);
			this->Controls->Add(this->tableLayoutPanel1);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->menuStrip2);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->Margin = System::Windows::Forms::Padding(6);
			this->Name = L"QLife";
			this->Text = L"QLife";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart1))->EndInit();
			this->menuStrip2->ResumeLayout(false);
			this->menuStrip2->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Settings_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void settingsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void label10_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void label6_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void richTextBox2_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void tableLayoutPanel1_Paint(System::Object^  sender, System::Windows::Forms::PaintEventArgs^  e) {
}
private: System::Void menuStrip2_ItemClicked(System::Object^  sender, System::Windows::Forms::ToolStripItemClickedEventArgs^  e) {
}
};
}
